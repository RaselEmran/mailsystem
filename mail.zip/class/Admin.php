<?php 
include_once '../lib/database.php';
class Admin{
	private $db;
	private $fm;

	public function __construct(){
		$this->db = new database();
		
	}
	public function login($email,$password){
		$pass = md5($password);
		$sql = "SELECT * FROM admin WHERE email = '$email' AND password = '$pass'  ";
		$query = $this->db->link->query($sql);

		if ($query->num_rows == 1 ) {
			$info = $query->fetch_assoc();
			$_SESSION['email'] = $info['email'];
			$_SESSION['role'] = $info['role'];
			$_SESSION['name'] = $info['name'];
			//echo "<script>window.location = 'all_people.php';</script>";
			return 'login hobe but apni age thik koren admin a ki ki page rakben';
		}else{
			return "Email Or password Don't Match !"  ;
		}




	}

















}
 ?>